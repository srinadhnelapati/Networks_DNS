#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>

struct domain
{
char doma[1000];
int por;
char ip[1000];
};
void main()
{



struct domain root;
struct sockaddr_in my_addr,their_addr; 
int soc=socket(AF_INET,SOCK_DGRAM,0);
int note=0;
if(soc==-1)
{
printf("socket not created\n");
exit(0);
}
else
{
printf("socket created\n");
}

my_addr.sin_family=AF_INET;
my_addr.sin_port=htons(3493);
my_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
memset(&(my_addr.sin_zero),'\0',8);

bind(soc,(struct sockaddr *)&my_addr,sizeof(struct sockaddr));

char buf[1000];
int len=55;

int p=sizeof(struct sockaddr);
int kl=recvfrom(soc,buf,len,0,(struct sockaddr *)&their_addr,&p);
buf[kl]='\0';
//printf("%d",len);
printf("%d\n",kl);
//printf("dksa%ddkjsa\n",kl);
len=kl;
printf("%s\n",buf);
int i;
int ctr=0;
char dom[1000];



for(i=kl-1;i>=0;i--)
{
if(buf[i]=='.')
{
int m;

for(m=i+1;m<kl;m++)
{

dom[ctr]=buf[m];
ctr=ctr+1;
}
break;
}
else
continue;
}




printf("%s\n",dom);
//printf("%d",ctr);

struct sockaddr_in lo_addr;
lo_addr.sin_family=AF_INET;
lo_addr.sin_port=htons(7777);
lo_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
memset(&(lo_addr.sin_zero),'\0',8);

//printf("print");

int f=sizeof(struct sockaddr); 
int l=sendto(soc,dom,ctr,0,(struct sockaddr *)&lo_addr,f);
//printf("%s",dom);
//------------------domain searching in root server------------------



int counter=0;





FILE *fp;

fp=fopen("domain.txt","r");
//printf("colundo\n");
int cmp;
char mes[100];
while(!feof(fp))
{
fscanf(fp,"%s %d %s",root.doma,&root.por,root.ip);
//printf("%d",root.por);
cmp=strcmp(root.doma,dom);
if(cmp==0)
{

printf("%d\n",root.por);
fclose(fp);
//break;
goto jum;
}
}

printf("not found\n");

strcpy(mes,"not found");
int lo=strlen(mes);

sendto(soc,mes,lo,0,(struct sockaddr *)&lo_addr,sizeof(struct sockaddr));




exit(0);
//------------------------------------




jum:

strcpy(mes,"found");
int ps=strlen(mes);


int iuy=sizeof(struct sockaddr);
sendto(soc,mes,ps,0,(struct sockaddr *)&lo_addr,iuy);




cmp=cmp+1;
int ydh=0;
int port=root.por;
cmp=sizeof(struct sockaddr);
sendto(soc,&port,sizeof(int),0,(struct sockaddr *)&lo_addr,cmp);

char uip[1000];
strcpy(uip,root.ip);
int bn=strlen(uip);
sendto(soc,uip,bn,0,(struct sockaddr *)&lo_addr,sizeof(struct sockaddr));

printf("%s\n",uip);


}
