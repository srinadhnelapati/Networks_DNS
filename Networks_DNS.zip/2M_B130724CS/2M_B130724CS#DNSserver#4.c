#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<netinet/in.h>
struct domain
{
char name[1000];
char addr[1000];
};
void main()
{

struct domain aut;
struct sockaddr_in my_addr;
struct sockaddr_in their_addr;
int soc=socket(PF_INET,SOCK_DGRAM,0);
my_addr.sin_family=AF_INET;
my_addr.sin_port=htons(4441);
my_addr.sin_addr.s_addr=inet_addr("127.0.1.10");
memset(&(my_addr.sin_zero),'\0',8);
int bi=bind(soc,(struct sockaddr *)&my_addr,sizeof(struct sockaddr));
if(bi==-1)
{
printf("bind is not done\n");
exit(0);
}
else
{
printf("binding done\n");
}

char new[1000];
int len=234;
printf("symbols\n");
int yr=sizeof(struct sockaddr);
int rec=recvfrom(soc,new,len,0,(struct sockaddr *)&their_addr,&yr);

printf("addr\n");
printf("%d\n",rec);
new[rec]='\0';
int i;
printf("%s",new);
FILE *fp;
fp=fopen("authorigoogle.txt","r");
while(!feof(fp))
{
fscanf(fp,"%s%s",aut.name,aut.addr);
if(strcmp(aut.name,new)==0)
{
printf("%s\n",aut.addr);
break;
}
}


fclose(fp);
struct sockaddr_in local_addr;
local_addr.sin_family=AF_INET;
local_addr.sin_port=htons(7777);
local_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
memset(&(local_addr.sin_zero),'\0',8);

char se[1000];
//int len;
strcpy(se,aut.addr);
len=strlen(se);
int re=sizeof(struct sockaddr);
int sen=sendto(soc,se,len,0,(struct sockaddr *)&local_addr,re);
printf("%d",sen);
}
