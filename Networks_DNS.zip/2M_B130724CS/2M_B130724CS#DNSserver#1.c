#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
struct ip
{
char name[1000];
char addr[1000];
};
void main()
{
struct ip ipd;
struct sockaddr_in my_addr;
struct sockaddr_in their_addr;
struct sockaddr_in edit_addr;

int soc=socket(AF_INET,SOCK_DGRAM,0);
if(soc==-1)
{
printf("socket not created\n");
exit(0);
}
else{
printf("socket created\n");
}
my_addr.sin_family=AF_INET;
my_addr.sin_port=htons(7777);
my_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
memset(&(my_addr.sin_zero),'\0',8);
int bi=bind(soc,(struct sockaddr *)&my_addr,sizeof(struct sockaddr));
if(bi==-1)
{
printf("binding failed\n");
exit(0);
}
else
{
printf("binding success\n");
}
//printf("random");

char arr[1000];
int len=90;
int yl=sizeof(struct sockaddr);

char array_tld[1000];
char array_authori[1000];
int k=recvfrom(soc,arr,len,0,(struct sockaddr *)&their_addr,&yl);
arr[k]='\0';
//printf("print");
printf("%s\n",arr);  //returns actual input-includes nslookup
len=strlen(arr);
strcpy(array_tld,arr);
strcpy(array_authori,arr);
printf("%d\n",k); 


//----------------cache code-----------------------------------------------------


int i,j;
char buf[1000];
for(i=9,j=0;i<len;i++,j++)
{
buf[j]=arr[i];
}
int ter;
ter=len-9;
char iop[1000];
strcpy(iop,buf);
//printf("%s\n",buf);
//printf("%d\n",ter);

struct sockaddr_in cli_addr;

FILE *fp;
fp=fopen("local_cache.txt","r");
while(!feof(fp))
{
fscanf(fp,"%s %s",ipd.name,ipd.addr);
if(strcmp(ipd.name,buf)==0)
{
printf("host name is present in cache\n");
printf("%s\n",ipd.addr);
char hg[1000];

cli_addr.sin_family=AF_INET;
cli_addr.sin_port=htons(3490);
cli_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
memset(&(cli_addr.sin_zero),'\0',8);

int cf=sizeof(struct sockaddr);
strcpy(hg,ipd.addr);
int bs=strlen(hg);
sendto(soc,hg,bs,0,(struct sockaddr *)&cli_addr,cf);
exit(0);
break;
}
}
fclose(fp);

//---------------------------------cache code ends-------------------------------









//----------------root server code------------------------------------------

struct sockaddr_in roo_addr;
roo_addr.sin_family=AF_INET;
roo_addr.sin_port=htons(3493);
roo_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
memset(&(roo_addr.sin_zero),'\0',8);

//strcpy(buf,arr);




 
int jr=sizeof(struct sockaddr);
k = sendto(soc,buf,ter,0,(struct sockaddr *)&roo_addr,jr);
printf("%d\n",k); //receives hostname




int jr1=sizeof(struct sockaddr);
int le=strlen(buf);
k= recvfrom(soc,buf,le,0,(struct sockaddr *)&edit_addr,&jr1);

buf[k]='\0';
printf("%d\n",k); //receives domain length
printf("%s\n",buf);  //receives domain
struct sockaddr_in pou_addr;
char ko[100];
int nj=98;
int lk=sizeof(struct sockaddr);
recvfrom(soc,ko,nj,0,(struct sockaddr *)&pou_addr,&lk);
if(strcmp(ko,"not found")==0)
{
printf("not found in records\n");
exit(0);
}



int port=0;
struct sockaddr_in some_addr;
int gf=sizeof(struct sockaddr); 
int poi=recvfrom(soc,&port,sizeof(int),0,(struct sockaddr *)&some_addr,&gf);


printf("%d",port);
struct sockaddr_in nm_addr;
char bde[1000];
int lkw=293;
int yua=recvfrom(soc,bde,lkw,0,(struct sockaddr *)&nm_addr,&gf);
printf("ip is %s",bde); 







//---------tld code------------------------------------

struct sockaddr_in top_addr;
top_addr.sin_family=AF_INET;
top_addr.sin_port=htons(port);
top_addr.sin_addr.s_addr=inet_addr(bde);
memset(&(top_addr.sin_zero),'\0',8);
int portnum;
portnum=port;
int n=strlen(array_tld);
int count_dots=0,iter=0;
char new[1000];
for(i=n-1;i>=0;i--)
{
if(array_tld[i]=='.')
{
count_dots=count_dots+1;
if(count_dots==2)
{ i=i+1;
break;
}

}
}
printf("pos%d\n",i);
int q=i;
for(q=i;q<n;q++)
{
new[iter]=array_tld[q];
iter=iter+1;
}

for(i=0;i<iter;i++)     //returns domain name
printf("%c\n",new[i]);
new[i]='\0';

//printf("stringlength%d",iter);
struct sockaddr_in tld_addr;
int er=strlen(new);
//printf("check%s\n",new);
int length=sizeof(struct sockaddr);
int sent=sendto(soc,new,iter,0,(struct sockaddr *)&top_addr,length);
new[sent]='\0';
printf("%d\n",sent); 	//receives domain name length 
printf("%s",new); 	//receives domain name
int port_tld=0,size=432;

int rec=recvfrom(soc,&port_tld,size,0,(struct sockaddr *)&tld_addr,&length);

printf("bytes received from tld:%d\n",rec);
printf("port number received from tld:%d\n",port_tld);

struct sockaddr_in vd_addr;
char tr[1000];
int ns=572;
int cd=recvfrom(soc,tr,ns,0,(struct sockaddr *)&vd_addr,&length);
printf("%d\n",cd);
printf("%s\n",tr);




//---------------authoritative server code---------------

int siz=strlen(array_authori);
printf("%d\n",siz); 
int count=0;
for(i=9;i<siz;i++)
{
new[count]=array_authori[i];
count=count+1;
}
printf("%s\n",new);    //hostname will get returned
new[count]='\0';
int s=strlen(new);


struct sockaddr_in aut_addr;
aut_addr.sin_family=AF_INET; 
aut_addr.sin_port=htons(port_tld); //here we use port number of authoritative server
printf("port number:%d\n",port_tld);
aut_addr.sin_addr.s_addr=inet_addr(tr);
memset(&(aut_addr.sin_zero),'\0',8);
int ye=sizeof(struct sockaddr);
sent=sendto(soc,new,s,0,(struct sockaddr *)&aut_addr,ye);

printf("number of bytes sent:%d\n",sent);
printf("%s\n",new); 
struct sockaddr_in byt_addr;
char term[1000];
int t=832;
rec=recvfrom(soc,term,t,0,(struct sockaddr *)&byt_addr,&ye);
term[rec]='\0';
printf("%d\n",rec);
printf("%s\n",term);
printf("home\n");
struct sockaddr_in cl_addr;
cl_addr.sin_family=AF_INET;
cl_addr.sin_port=htons(3490);
cl_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
memset(&(cl_addr.sin_zero),'\0',8);




//-------caching code-------------------------------------------------------
FILE *ui;
ui=fopen("local_cache.txt","a");
char ch;
printf("socket\n");

fprintf(ui," %s %s",iop,term);

fclose(ui);

int sentt=sendto(soc,term,rec,0,(struct sockaddr *)&cl_addr,ye);
printf("%d",sentt);

}
