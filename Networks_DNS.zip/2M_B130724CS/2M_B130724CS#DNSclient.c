#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
void main()
{

int soc;
struct sockaddr_in cli_addr,to_addr;
soc=socket(AF_INET,SOCK_DGRAM,0);
if(soc==-1)
{
printf("socket creation failed\n");
exit(0);
}
else
{
printf("socket created\n");
}
cli_addr.sin_family=AF_INET;
cli_addr.sin_port=htons(3490);
cli_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
memset(&(cli_addr.sin_zero),'\0',8);
//struct sockaddr_in to_addr;
bind(soc,(struct sockaddr *)&cli_addr,sizeof(struct sockaddr));

to_addr.sin_family=AF_INET;
to_addr.sin_port=htons(7777);
to_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
memset(&(to_addr.sin_zero),'\0',8);

int n,i=-1;
char arr[1000],a;
while(1)
{

scanf("%c",&a);
if(a=='\n')
 break;
else
{
i=i+1;
arr[i]=a;
}
}


n=i+1;
//printf("%d",n);
int ui=sizeof(struct sockaddr);
int k=sendto(soc,arr,n,0,(struct sockaddr *)&to_addr,ui);
printf("%d\n",k);
for(i=0;i<n;i++)
printf("%c",arr[i]);
printf("\n");
struct sockaddr_in loc_addr;
char mnb[1000];
int m=873;

int rec=recvfrom(soc,mnb,m,0,(struct sockaddr *)&loc_addr,&ui);
mnb[rec]='\0';
printf("%s\n",mnb);
printf("%d\n",rec);

}
