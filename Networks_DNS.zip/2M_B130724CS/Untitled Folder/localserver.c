#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>

void main()
{
struct sockaddr_in my_addr;
struct sockaddr_in their_addr;

int soc=socket(AF_INET,SOCK_DGRAM,0);
if(soc==-1)
{
printf("socket not created\n");
exit(0);
}
else{
printf("socket created\n");
}
my_addr.sin_family=AF_INET;
my_addr.sin_port=htons(7777);
my_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
memset(&(my_addr.sin_zero),'\0',8);
int bi=bind(soc,(struct sockaddr *)&my_addr,sizeof(struct sockaddr));
if(bi==-1)
{
printf("binding failed\n");
exit(0);
}
else
{
printf("binding success\n");
}
printf("random");

char arr[1000];
int len=90;
int yl=sizeof(struct sockaddr);


int k=recvfrom(soc,arr,len,0,(struct sockaddr *)&their_addr,&yl);
arr[k]='\0';
printf("print");
printf("%s\n",arr );
//len=strlen(arr);
printf("%d",k);
//----------------root server code------------------------------------------

struct sockaddr_in roo_addr;
roo_addr.sin_family=AF_INET;
roo_addr.sin_port=htons(3493);
roo_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
memset(&(roo_addr.sin_zero),'\0',8);

//strcpy(buf,arr);
int i,j;
char buf[1000];
for(i=9,j=0;i<len;i++,j++)
{
buf[j]=arr[i];
}
int ter=len-9;
int jr=sizeof(struct sockaddr);
k = sendto(soc,buf,ter,0,(struct sockaddr *)&roo_addr,jr);

char dom[1000];
int le;
jr=sizeof(struct sockaddr);
k= recvfrom(soc,dom,le,0,(struct sockaddr *)&roo_addr,&jr);
printf("%d",le);
printf("%s",dom);


}
