#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
struct domainname
{
char name[1000];
int numport;
char ip[1000];
};
void main()
{
struct sockaddr_in my_addr;
struct sockaddr_in their_addr;
struct domainname tldcom;
int soc=socket(PF_INET,SOCK_DGRAM,0);

my_addr.sin_family=AF_INET;
my_addr.sin_port=htons(3333);
my_addr.sin_addr.s_addr=inet_addr("127.0.0.10");
memset(&(my_addr.sin_zero),'\0',8);

bind(soc,(struct sockaddr *)&my_addr,sizeof(struct sockaddr));
char arr[1000];
int mes,len=512;
int length=sizeof(struct sockaddr);
mes=recvfrom(soc,arr,len,0,(struct sockaddr *)&their_addr,&length);
arr[mes]='\0';
printf("%d",mes);
printf("%s\n",arr);
FILE *fp;
int cmp;
fp=fopen("tldcom.txt","r");
while(!feof(fp))
{
fscanf(fp,"%s %d %s",tldcom.name,&tldcom.numport,tldcom.ip);
if(strcmp(tldcom.name,arr)==0)
{
printf("%d\n",tldcom.numport);
break;
}
}
fclose(fp);

struct sockaddr_in local_addr;
local_addr.sin_family=AF_INET;
local_addr.sin_port=htons(7777);
local_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
memset(&(local_addr.sin_zero),'\0',8);

int messa=tldcom.numport;
//int length=sizeof(struct sockaddr);
sendto(soc,&messa,sizeof(int),0,(struct sockaddr *)&local_addr,length);
printf("%d\n",messa);


char pl[1000];
strcpy(pl,tldcom.ip);
int bd=strlen(pl);
int pg=sendto(soc,pl,bd,0,(struct sockaddr *)&local_addr,length);
printf("%d\n",pg);
printf("%s\n",pl);




}
